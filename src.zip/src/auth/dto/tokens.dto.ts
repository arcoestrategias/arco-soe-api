export class TokensDto {
  accessToken: string;
  refreshToken: string;
}
