export interface CurrentUserPayload {
  sub: string; // estándar JWT
}
