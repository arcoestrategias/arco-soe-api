export class ResponseCommentDto {
  id!: string;
  labelCreatedBy!: string;
  labelCreatedAt!: string;
  labelUpdatedBy!: string;
  labelUpdatedAt!: string;
  name!: string;
  isActive!: boolean;
}
