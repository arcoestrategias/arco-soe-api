import { IsArray, IsInt, IsOptional, IsString, IsUUID, IsEnum, IsNumber, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

export class ConfigureAllStructureObjectiveDto {
  // --- Objective (solo campos que podrían cambiar aquí) ---
  @IsOptional() @IsString()
  name?: string;

  @IsOptional() @IsString()
  description?: string | null;

  @IsOptional() @IsNumber()
  goalValue?: number | null;

  // --- Indicator (configuración) ---
  @IsOptional() @IsEnum(['POS','NEG'])
  tendence?: 'POS' | 'NEG';

  @IsOptional() @IsEnum(['POR','RAT','UNI','MON','UNC'])
  measurement?: 'POR' | 'RAT' | 'UNI' | 'MON' | 'UNC';

  @IsOptional() @IsEnum(['TRI','QTR','MES','STR','ANU','PER'])
  frequency?: 'TRI' | 'QTR' | 'MES' | 'STR' | 'ANU' | 'PER';

  @IsOptional() @IsString()
  origin?: string | null;

  @IsOptional() @IsString()
  type?: string | null;

  @IsOptional() @IsString()
  reference?: string | null;

  // YYYY-MM (como string) o Date, según tu estándar actual
  @IsOptional() @IsString()
  fromAt?: string;

  @IsOptional() @IsString()
  untilAt?: string;

  // --- Array de periodos a crear/preservar en ObjectiveGoal ---
  @IsArray() @ValidateNested({ each: true }) @Type(() => PeriodDto)
  periods: PeriodDto[];
}

export class PeriodDto {
  @IsInt()
  month: number; // 1..12

  @IsInt()
  year: number;  // e.g. 2025
}
